;<?php die(''); ?>
;for security reasons, don't remove or modify the first line

; a preference is declared like this :
;[pref:my.pref]
; type of the preference "string" | "integer" | "boolean" | "decimal" (default string)
;type=
; locale key that describe the preference
;locale =
; identifier of the preference group 
;group =
; acl_subject of the right required to read the preference in admin panel
;read_acl_subject =
; acl_subject of the right required to modify the preference in admin panel
;write_acl_subject =
; default value to restore from admin panel
;default_value =

; a group is declared like this :
;[group:my.group]
; locale key for the group
;locale =
; order to display in admin panel
;order = 




;<?php die(''); ?>
; for security reasons , don't remove or modify the first line
; don't modify this file if you don't know what you do. it is generated automatically by jInstaller


[index]
jelix.installed=1
jelix.version=1.4.1
jacl.installed=0
jacl.version=
jacl2db.installed=0
jacl2db.version=
jacldb.installed=0
jacldb.version=
jauth.installed=1
jauth.version=1.2.1
jauthdb.installed=1
jauthdb.version=1.2.1
junittests.installed=0
junittests.version=
jWSDL.installed=0
jWSDL.version=
jelix.version.date="2012-10-25 17:08"
jelix.firstversion=1.4.1
jelix.firstversion.date="2012-10-25 17:08"
Bibli.installed=1
Bibli.version=0.1pre
jauth.version.date=2011-10-18
jauth.firstversion=1.2.1
jauth.firstversion.date=2011-10-18
jauthdb.version.date=2011-10-18
jauthdb.firstversion=1.2.1
jauthdb.firstversion.date=2011-10-18
[__modules_data]
jelix.contexts="db:default"


jauth.contexts="auth:index/auth.coord.ini.php"

jauthdb.contexts="index/auth.coord.ini.php,db:default"


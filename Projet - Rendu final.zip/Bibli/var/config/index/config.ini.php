;<?php die(''); ?>
;for security reasons , don't remove or modify the first line

startModule=Bibli
startAction="default:index"

[responses]
[modules]
Bibli.access=2

jauth.access=2
jauthdb.access=2
[coordplugins]
auth="index/auth.coord.ini.php"


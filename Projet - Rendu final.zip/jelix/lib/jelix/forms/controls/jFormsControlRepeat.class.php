<?php
/**
* @package     jelix
* @subpackage  forms
* @author      Laurent Jouanneau
* @copyright   2008 Laurent Jouanneau
* @link        http://www.jelix.org
* @licence     http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public Licence, see LICENCE file
*/

/*
 * repeat
 * @package     jelix
 * @subpackage  forms
 * @experimental
 */
class jFormsControlRepeat extends jFormsControlGroups {
    public $type="repeat";
}

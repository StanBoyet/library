<!DOCTYPE html>
<html>
<head>

<title>Application Error</title>
<?php echo $HEADBOTTOM;?>
</head>
<body>
<?php echo $BODYTOP;?>
<p>Error 500. 
A technical error has occured. Sorry for this trouble.</p>
<?php echo $BODYBOTTOM;?>
</body>
</html>